package service;

import org.junit.Test;

public class LogbackFileLoggerTest {

	@Test
	public void testLogInfo2file() {
		// 日志输出到程序根目录(classpath)
		String workDir = FileLogger.class.getResource("/").getPath();
		System.setProperty("WORKDIR", workDir);

		LogbackFileLogger logger = new LogbackFileLogger();
		logger.logInfo2file();
	}

}
