package service;

import org.junit.Test;

public class FileLoggerTest {

	@Test
	public void testLogInfo2file() {
		// 日志输出到程序根目录(classpath)
		String workDir = FileLogger.class.getResource("/").getPath();
		System.setProperty("WORKDIR", workDir);
		
		FileLogger logger = new FileLogger();
		logger.logInfo2file();
	}

}
