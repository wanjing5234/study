package main;

import service.LogbackFileLogger;

/**
 * Linux服务安装入口类
 * 
 * @author mason
 *
 */
public class DaemonMainClassForLinux {
	public static void init(String[] args) {
		//日志输出到程序根目录(classpath)
		MainClass.initWorkDir();
	}

	public static void destroy() {
	}

	public static void start() {
		LogbackFileLogger logger = new LogbackFileLogger();
		logger.logInfo2file();
	}

	public static void stop() {
		System.exit(0);
	}
}
