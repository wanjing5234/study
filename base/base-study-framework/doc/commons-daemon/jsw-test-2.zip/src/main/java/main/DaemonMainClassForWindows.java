package main;

import service.LogbackFileLogger;

/**
 * Windows服务安装入口类
 * 
 * @author mason
 *
 */
public class DaemonMainClassForWindows {

	public static void start(String[] args) {
		// 日志输出到程序根目录(classpath)
		MainClass.initWorkDir();
		LogbackFileLogger logger = new LogbackFileLogger();
		logger.logInfo2file();
	}

	public static void stop(String[] args) {
		System.exit(0);
	}
}
