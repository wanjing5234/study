package main;

import service.FileLogger;

/**
 * 程序主入口
 * 
 * @author mason
 *
 */
public class MainClass {

	public static void main(String[] args) {
		MainClass.initWorkDir();
		
		FileLogger logger = new FileLogger();
		logger.logInfo2file();
	}

	/**
	 * 日志输出到程序根目录(classpath)
	 */
	public static void initWorkDir() {
		String workDir = FileLogger.class.getResource("/").getPath();
		System.setProperty("WORKDIR", workDir);
	}
}
