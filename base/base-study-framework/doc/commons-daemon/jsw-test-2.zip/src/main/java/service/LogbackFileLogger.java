package service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogbackFileLogger {
	private static Logger logger = LoggerFactory.getLogger(LogbackFileLogger.class);

	public void logInfo2file() {
		for (int i = 0; i < 50; i++) {
			logger.info("我的测试：my test{}", i);
			try {
				//睡眠一秒以维持服务运行
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage(),e);
			}
		}
	}
}
